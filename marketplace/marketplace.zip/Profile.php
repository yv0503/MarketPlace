<?php session_start();?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Online Market</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="assets/design.css">
    </head>
<?php

include "widgets/dashboard.php";
include "connection.php";

?>

<body class="mainBackground">

        <div class ="container6">
            <div class="registerGUI columnItem" style="--position: 1">
            <form method= "POST" class="login">
                <p class ="Logintext2 item5">Personal Information</p>
                <?php
                $name = $_SESSION['name'];
                $sql = "SELECT * FROM userInfo WHERE UserName = '$name'";
$result = $conn->query($sql);
$resultcheck = mysqli_num_rows($result);

if ($resultcheck > 0){
    while($row = mysqli_fetch_assoc($result)){   
?> 
<p class ="Registertext registerItem" style="--positioncolumn: 1; --positionrow: 2" >Username</p>
                <p class ="Registertext registerItem" style="--positioncolumn: 1; --positionrow: 4" >Email Address</p>
                <p class ="Registertext registerItem" style="--positioncolumn: 1; --positionrow: 6">Password</p>
                <p class ="Registertext registerItem" style="--positioncolumn: 1; --positionrow: 8" >Confirm Password</p>
                <p class ="Registertext registerItem" style="--positioncolumn: 2; --positionrow: 2">First Name</p>
                <p class ="Registertext registerItem" style="--positioncolumn: 2; --positionrow: 4" >Last Name</p>
                <p class ="Registertext registerItem" style="--positioncolumn: 2; --positionrow: 6">Contact Number</p>
                <p class ="Registertext registerItem" style="--positioncolumn: 2; --positionrow: 8">Country</p>
                <p class ="Registertext registerItem" style="--positioncolumn: 1; --positionrow: 10">City</p>
                <p class ="Registertext registerItem" style="--positioncolumn: 2; --positionrow: 10" >Province</p>
                <p class ="Registertext registerItem" style="--positioncolumn: 1; --positionrow: 12">Post Code</p>
                <p class ="Registertext registerItem" style="--positioncolumn: 2; --positionrow: 12">Address Line</p>

    <input type="text" name="username" class="user registerItem" style="--positioncolumn: 1; --positionrow: 3" value="<?php echo $row['UserName']?>">
    <input type="email" name="email" class="user registerItem " style="--positioncolumn: 1; --positionrow: 5" value="<?php echo $row['email']?>">
    <input type="password" name="password" class="user password registerItem" style="--positioncolumn: 1; --positionrow: 7" value="12345">
    <input type="password" name="confirm_password" class="user password registerItem " style="--positioncolumn: 1; --positionrow: 9" value="12345">
    <input type="text" name="first_name" class="user registerItem" style="--positioncolumn: 2; --positionrow: 3" value="<?php echo $row['firstName']?>">
    <input type="text" name="last_name" class="user registerItem " style="--positioncolumn: 2; --positionrow: 5" value="<?php echo $row['lastName']?>">
    <input type="text" name="contact_number" class="user registerItem" style="--positioncolumn: 2; --positionrow: 7" value="<?php echo $row['contactNumber']?>">
    <input type="text" name="country" class="user registerItem " style="--positioncolumn: 2; --positionrow: 9" value="<?php echo $row['country']?>">
    <input type="text" name="city" class="user registerItem " style="--positioncolumn: 1; --positionrow: 11" value="<?php echo $row['city']?>">
    <input type="text" name="province" class="user registerItem " style="--positioncolumn: 2; --positionrow: 11" value="<?php echo $row['province']?>">
    <input type="text" name="postalcode" class="user registerItem " style="--positioncolumn: 1; --positionrow: 13" value="<?php echo $row['postalCode']?>">
    <input type="text" name="addressline" class="user registerItem " style="--positioncolumn: 2; --positionrow: 13" value="<?php echo $row['addressline']?>">

    <button type="submit" class="loginbutton Logintext registerItem2 " style="--positioncolumn: 1; --positionrow: 14">Confirm</button>
</form>>

<?php

        }
    }?>
                

            
        </div>


        

        <div class="banner">
            <div class="slider" style="--quantity: 10;">
                <div class="item" style="--position: 1"><img src="headset.png"></div>
                <div class="item" style="--position: 2"><img src="jacket.png"></div>
                <div class="item" style="--position: 3"><img src="jacket.png"></div>
                <div class="item" style="--position: 4"><img src="jacket.png"></div>
                <div class="item" style="--position: 5"><img src="jacket.png"></div>
                <div class="item" style="--position: 6"><img src="headset.png"></div>
                <div class="item" style="--position: 7"><img src="headset.png"></div>
                <div class="item" style="--position: 8"><img src="headset.png"></div>
                <div class="item" style="--position: 9"><img src="headset.png"></div>
                <div class="item" style="--position: 10"><img src="headset.png"></div>
            </div>
        </div>
        
        <script src="" async defer></script>
    </body>
</html>