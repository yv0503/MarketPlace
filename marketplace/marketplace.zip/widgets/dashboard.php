<!DOCTYPE html>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="design.css">
    <title>Document</title>
</head>

<?php
if (empty($_SESSION['name']))
{
        HEADER("Location: loginpage.php");
    }
include "connection.php";
include "loginHandling.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    if (isset($_POST)) {
        foreach ($_POST as $key => $value) {
            // If the login button is clicked
        
            if ($key == "profile") {

                Header("Location: Profile.php");
            }

            if ($key == "purchases") {

                Header("Location: Profile.php");
            }

            if ($key == "products") {

                Header("Location: Profile.php");
            }

            if ($key == "Logout")
            {
                Header("Location: Logout.php");
            }

            if ($key == "Home")
            {
                Header("Location: homepage.php");
            }

        }
    }
}
?>
<body>
<header class="header">
            <div class="container" style="--quantity: 2">

                <div class="container3 item" style="--position: 1">
                    <button name="Home" id="Home" class="headerFont"><img src="fireflymikyuru.jpg" class="headerImg"></button>
                    <button name="Home" id="Home" class="headerFont">Username</button>
                    <button name="Currency" id="Currency" class="BalanceFont">Balance : 0</button>
                </div> 

                <form method="POST" class="container3 item" style="--quantity: 5; --position: 2">
                    <button name="profile" id="profile" class="headerStyle item" style="--position: 1">Profile</button>
                    <button name="purchases" id="purchases" class="headerStyle item" style="--position: 2">Purchases</button>
                    <button name="products" id="products" class="headerStyle item" style="--position: 4">My Products</button>
                    <button name="Logout" id="Logout" class="headerStyle item" style="--position: 5">Logout</button>
                </form>
                
            </div>
        </header>
</body>
</html>