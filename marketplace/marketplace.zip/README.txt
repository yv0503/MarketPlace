MYSQL ako nag database
wala pa dyan yung admin page and shit