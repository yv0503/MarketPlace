
<!DOCTYPE html>
<?php session_start();?>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="description" content="">
        <title>Online Market</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="./assets/design.css">
        <script defer src="main.js"></script>
    </head>

    <?php
    include "widgets/dashboard.php";
    include "connection.php";
    
    ?>

    <body class="mainBackground scroll">
        <div class="container5 item" style="--quantity: 2">
            <div class="TopSellers" style="--position: 1">
                <p class="TitleFont hidden">Hot Deals</p>
                
            </div>

            <div class="ProductsLists item" style="--quantity: 2;--position: 2">

                <form method="POST" class="Category hidden" style="--position: 1">
                    <button class="CategoriesStyle item" style="--position: 1">Shop by Categories</button>
                    <button name="Technology" id="Technology" class="CategoriesStyle1 item" style="--position: 2">Technology</button>
                    <button name="Clothes" id="Clothes" class="CategoriesStyle1 item" style="--position: 3">Clothes</button>
                    <button name="Technology" id="Technology" class="CategoriesStyle1  item" style="--position: 4">Food</button>
                    <button name="Technology" id="Technology" class="CategoriesStyle1 item" style="--position: 5">Furniture</button> 
                    <button name="Technology" id="Technology" class="CategoriesStyle1 item" style="--position: 6">Cars</button>
                    <button name="Clothes" id="Clothes" class="CategoriesStyle2 item" style="--position: 2">Appliances</button>
                    <button name="Technology" id="Technology" class="CategoriesStyle2  item" style="--position: 3">Tools</button>
                    <button name="Technology" id="Technology" class="CategoriesStyle2 item" style="--position: 4">School Supplies</button>        
                </form>
<?php
    
    if ($_SERVER["REQUEST_METHOD"] != "POST") {

$sql = "SELECT * FROM products";
$result = $conn->query($sql);
$resultcheck = mysqli_num_rows($result);

if ($resultcheck > 0){
    while($row = mysqli_fetch_assoc($result)){   
?> 
<div class="Products hidden" style="--position: 1">
<div class="item" style="--position: 1"><img src="assets/headset.png" class="ProductImg"></div>
<div class="ProductDescription item" style="--position: 2"><p class="ProductFont"><?php echo $row['productDesc']?></p></div>
<div class="ProductSeller item" style="--position: 3"><p class="ProductFont2"><?php echo $row['productPrice']?></p></div>
<div class="ProductPrice item" style="--position: 4"><p class="ProductFont2"><?php echo $row['productPrice']?></p></div>
<Button class="ProductBuy BuyButton item" style="--position: 5">Buy</button>           
</div>

<?php

        }
    }
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
if (isset($_POST)) {
    foreach ($_POST as $key => $value) {

        if ($key == "Clothes") {
                $sql = "SELECT * FROM products WHERE productType = 'Clothing'";
                $result = $conn->query($sql);
                $resultcheck = mysqli_num_rows($result);

if ($resultcheck > 0){
    while($row = mysqli_fetch_assoc($result)){   
?> 
<div class="Products hidden" style="--position: 1">
<div class="item" style="--position: 1"><img src="assets/headset.png" class="ProductImg"></div>
<div class="ProductDescription item" style="--position: 2"><p class="ProductFont"><?php echo $row['productDesc']?></p></div>
<div class="ProductSeller item" style="--position: 3"><p class="ProductFont2"><?php echo $row['productPrice']?></p></div>
<div class="ProductPrice item" style="--position: 4"><p class="ProductFont2"><?php echo $row['productPrice']?></p></div>
<Button class="ProductBuy BuyButton item" style="--position: 5">Buy</button>           
</div>

<?php

            }
        }

    }
}

if ($key == "Technology") {
        $sql = "SELECT * FROM products WHERE productType = 'Technology'";
        $result = $conn->query($sql);
        $resultcheck = mysqli_num_rows($result);

if ($resultcheck > 0){
while($row = mysqli_fetch_assoc($result)){   
?> 
<div class="Products hidden" style="--position: 1">
<div class="item" style="--position: 1"><img src="assets/headset.png" class="ProductImg"></div>
<div class="ProductDescription item" style="--position: 2"><p class="ProductFont"><?php echo $row['productDesc']?></p></div>
<div class="ProductSeller item" style="--position: 3"><p class="ProductFont2"><?php echo $row['productPrice']?></p></div>
<div class="ProductPrice item" style="--position: 4"><p class="ProductFont2"><?php echo $row['productPrice']?></p></div>
<Button class="ProductBuy BuyButton item" style="--position: 5">Buy</button>           
</div>

<?php

                }
            }

        }
    }

}


?>         
        </div>



        
        <script src="" async defer></script>
    </body>
</html>